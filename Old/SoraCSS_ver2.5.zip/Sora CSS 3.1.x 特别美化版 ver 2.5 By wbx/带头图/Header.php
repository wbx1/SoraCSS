<?php
namespace InnStudio\Theme\Tpls;

use InnStudio\Theme\Apps\Cache\Other;
use InnStudio\Theme\Apps\Url\Api as Url;
use InnStudio\Theme\Apps\User\Api as User;
use InnStudio\Theme\Apps\Menu\Api as Menu;
use InnStudio\Theme\Apps\Condition\Api as Condition;
use InnStudio\Theme\Apps\Language\L10n;
use InnStudio\Theme\Apps\Snippets\Functions;
use InnStudio\Theme\Apps\Advertisement\Api as Advertisement;
use InnStudio\Theme\Addons\Banner\Api as Banner;
use InnStudio\Theme\Apps\Hook\Api as Hook;

class Header
{
    public function __construct()
    {
        $this->head();
        $this->body();
        $this->toolMenu();
        $this->mobileMenu();
        $this->navMain();
    }

    private function head()
    {
        ?><!DOCTYPE html>
        <html lang="<?= Other::getBlogInfo('language');?>">
        <head>
            <?php
            $this->meta();
            \wp_head();
            ?>
        </head><?php
    }

    private function meta()
    {
        $metas = [
            'meta' => [
                [
                    'charset' => Other::getBlogInfo('charset')
                ], [
                    'http-equiv' => 'X-UA-Compatible',
                    'content' => 'IE=edge',
                ], [
                    'http-equiv' => 'Cache-Control',
                    'content' => 'no-transform',
                ], [
                    'http-equiv' => 'Cache-Control',
                    'content' => 'no-siteapp',
                ], [
                    'renderer' => 'webkit',
                ], [
                    'name' => 'viewport',
                    'content' => 'width=device-width,initial-scale=1,user-scalable=no',
                ], [
                    'name' => 'author',
                    'content' => 'INN STUDIO',
                ],
            ],
            'link' => [
                [
                    'rel' => 'profile',
                    'href' => 'http://gmpg.org/xfn/11',
                ], [
                    'rel' => 'pingback',
                    'href' => Other::getBlogInfo('pingback_url'),
                ],
            ],
        ];
        $metas = Hook::applyFilters('frontendMetas', (array)$metas);
        $html = '';

        foreach ($metas as $metaTag => $metaGroups) {
            foreach ($metaGroups as $metaGroup) {
                $kv = [];

                foreach ($metaGroup as $metaKey => $metaValue) {
                    $kv[] = $metaKey . '="' . $metaValue . '"';
                }

                $html .= "<{$metaTag} " . implode(' ', $kv) . "/>";
            }
        }

        unset($metas);
        echo $html;
    }

    private function body()
    {
        ?>
        <body <?php \body_class(); ?>>
        <div class="banner-container"style="background-image: url(https://ooo.0o0.ooo/2017/04/01/58de8e49a44b5.jpg);height: 180px;background-size: 100% 100%;background-position:center;"><div class="g"><div style="margin-top: 1rem"><a href="http://google.com"class="custom-logo-link"rel="home"itemprop="url"title="acg"><img width="200"height="90"src="https://ooo.0o0.ooo/2017/04/01/58de8e49746da.png"class="custom-logo"alt=""itemprop="logo"></a></div></div></div>
        <?php
    }

    private function mobileMenu()
    {
        if (\wp_is_mobile()) {
            ?>
            <div id="header-nav-slide" class="nav-slide menu-mobile header-nav-slide animated">
                <a href="<?= Url::getHome();?>" class="nav-slide-header">
                    <?= Other::getBlogInfo('name');?>
                </a>
                <?= Menu::navMenu([
                    'theme_location' => User::isUserLoggedIn() ? 'headerMainMenuMobileLogged' : 'headerMainMenuMobile',
                    'container_class' => '',
                    'menu_id' => 'menu-mobile',
                ]);?>
            </div>
        <?php
        }
    }

    private function toolMenu()
    {
        if (\wp_is_mobile()) {
            return;
        }

        if (! class_exists(Banner::class) || ! Banner::isEnabled()) {
            return;
        }

        $menu = Menu::navMenu([
            'theme_location' => User::isUserLoggedIn() ? 'headerToolMenuLogged' : 'headerToolMenu',
            'container_class' => '',
        ]);

        if ($menu === 'empty' || ! $menu) {
            return;
        }

        ?>
        <div class="nav-tool-menu animated fadeIn">
            <div class="g">
                <?= $menu;?>
            </div>
        </div>
        <?php
    }

    private function navMain()
    {
        $mobileClass = \wp_is_mobile() ? 'mobile' : null;
        ?>
        <div class="nav-main animated <?= $mobileClass;?>">
            <div class="g">
                <?php
                $this->seoName();
                $this->navMobileIcon();
                echo $this->logo();
                $this->desktopMenu();
                $this->tools();
                $this->placeholder();
                ?>
            </div>
        </div>
        <div class="nav-main-placeholder"></div>
        <?php
        $this->ad();
    }

    private function seoName()
    {
        if (Condition::isHome() || Condition::isFrontPage()) {
            ?><h1 hidden><?= sprintf(L10n::__('%s - Homepage'), Other::getBloginfo('name'));?></h1><?php
        }
    }

    private function navMobileIcon()
    {
        if (\wp_is_mobile()) {
            ?>
            <div id="navicon-container">
                <a href="javascript:;" class="navicon fa fa-navicon fa-fw"></a>
            </div>
        <?php
        }
    }

    private function logo()
    {
        static $cache = null;

        if ($cache === null) {
            $cache = str_replace(
                'itemprop="url"',
                'itemprop="url" title="' . Other::getBloginfo('name') . ' - ' . Other::getBloginfo('description') . '"',
                \get_custom_logo()
            );
        }

        return $cache;
    }

    private function desktopMenu()
    {
        if (! \wp_is_mobile()) {
            echo Menu::navMenu([
                'theme_location' => User::isUserLoggedIn() ? 'headerMainMenuLogged' : 'headerMainMenu',
                'container_class' => 'menu-header hidden-tablet hidden-phone',
                'menu_id' => 'menu-header',
            ]);
        }
    }

    private function tools()
    {
        ?>
        <div class="tool-container">
            <div id="header-account-container"></div>
            <div id="search-bar-btn-container"></div>
        </div>
        <?php
    }

    private function placeholder()
    {
        ?>
        <div class="nav-main-placeholder"></div>
        <?php
    }

    private function ad()
    {
        if (Condition::isFrontPage() || Condition::isHome()) {
            return;
        }

        if (! class_exists(Advertisement::class)) {
            return;
        }

        $adcode = Advertisement::getFrontendCode('belowHeaderMenu');

        if (empty($adcode)) {
            return;
        }
        ?>
        <div class="g ad-container ad-below-header-menu"><?= $adcode;?></div>
        <?php
    }
}
